# YoloV3_640 > 2022-10-15 7:25am
https://universe.roboflow.com/object-detection/yolov3_640

Provided by Roboflow
License: CC BY 4.0

